Kunoichi Yami Beta
Created by Louis-N. Dozois and Phil Stroffolino
pstroffo@yahoo.com
lndozois@rogers.com

As Yami, a kunoichi (woman ninja) of the kage clan, your mission is to 
assassinate the local Shogun, lord Asano. Asano's troops have been 
forcefully moving into territories and ruling with an iron fist. The people 
can no longer survive under such harsh conditions, which is why they 
have turned to your clan for help. Move out, kill silently and without 
mercy.

Controls:
Press "start" to begin game.
D-pad to move. (forward, back, rotate right/left)
(A) slash
(B) parry
(R) crouch

Special techniques:
(R) + D-pad to roll/back hand-spring (these techniques are also 
possible by double tapping the appropriate direction while holding the crouch 
button)

(A) while snuck up on a guard to silently kill them

D-pad + (A) attack in the appropriate direction (forward does a normal 
attack)

Double tap forward to dash.

Tips:
Crouching makes you harder to see, use liberally!
When a guard spots you he will scream, alerting other guards. Avoid 
this by performing the silent kill.

Cheat:
Press "select" to skip current stage.

There are 10 stages in all.

