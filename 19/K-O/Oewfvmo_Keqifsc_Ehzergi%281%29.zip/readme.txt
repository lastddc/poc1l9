Name : Yannick ROUSSEAU
E-mail address : ryannick@numericable.fr

Entry description : Well, nothing new here, only a breakout clone. Hope you will enjoy it though !

Commands : Left / Right moves the racket, Button A launches the ball and fires in laser mode. Button B kills the ball (in case you are blocked).

I wans't able to try it on the real GBA hardware, but it works on all the emulators I've tried. I hope there's no problem.
