Kara Kara Cubes

GBA Programming: Matt Kyle
Design: Justin Leingang
Artwork: Justin Leingang, Matt Kyle

Kara Kara Cubes is a puzzle game.  The object of the game is to switch any
two cubes in the playfield to create groups of three or more horizontally
or vertically.  Doing so causes the groups to be removed and replacement 
cubes to fall from the top.  Removing cubes causes the Next Level bar to
increase.  Filling the bar moves to the next level.



Modes of play: Normal and Panic

Normal Mode

Switched cubes that result in a group or three or more will cause the Next
Level bar to move to the right.  Switched cubes that don't result in cubes
being removed cause the Next Level bar to move to the left.  The higher
the level, the more the penalty is.  When the bar is totally empty, the 
game is over.



Panic Mode

Switched cubes that result in a group or three or more will cause the Next
Level bar to move to the right.  Every two seconds the Next Level bar is 
decreased.  As the levels increase, the amount the bar moves to the left 
increases.